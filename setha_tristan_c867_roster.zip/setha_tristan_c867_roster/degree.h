#pragma once
#include <string> 
enum class DegreeProgram
{
  SECURITY,
  NETWORK,
  SOFTWARE
};

const std::string degreeString[] = {"SECURITY", "NETWORK", "SOFTWARE"};
